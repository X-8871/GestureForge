合成src/SYNTHETIC_0.sv
