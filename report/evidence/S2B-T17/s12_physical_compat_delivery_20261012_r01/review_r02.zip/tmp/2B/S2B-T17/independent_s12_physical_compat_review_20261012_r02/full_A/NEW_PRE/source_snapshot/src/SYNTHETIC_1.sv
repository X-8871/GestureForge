合成src/SYNTHETIC_1.sv
