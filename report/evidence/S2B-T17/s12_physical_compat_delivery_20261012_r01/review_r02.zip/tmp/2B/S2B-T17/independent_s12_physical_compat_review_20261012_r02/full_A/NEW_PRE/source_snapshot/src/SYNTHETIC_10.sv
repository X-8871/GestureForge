合成src/SYNTHETIC_10.sv
