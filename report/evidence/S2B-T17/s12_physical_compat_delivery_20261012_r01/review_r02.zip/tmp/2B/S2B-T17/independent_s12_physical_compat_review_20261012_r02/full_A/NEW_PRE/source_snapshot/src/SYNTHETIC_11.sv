合成src/SYNTHETIC_11.sv
