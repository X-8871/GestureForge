合成src/SYNTHETIC_12.sv
