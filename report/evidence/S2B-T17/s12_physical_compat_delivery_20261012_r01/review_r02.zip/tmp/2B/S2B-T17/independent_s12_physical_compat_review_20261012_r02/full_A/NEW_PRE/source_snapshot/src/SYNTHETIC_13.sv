合成src/SYNTHETIC_13.sv
