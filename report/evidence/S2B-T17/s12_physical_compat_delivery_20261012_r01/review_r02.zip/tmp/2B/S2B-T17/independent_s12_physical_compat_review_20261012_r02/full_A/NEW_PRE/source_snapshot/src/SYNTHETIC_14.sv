合成src/SYNTHETIC_14.sv
