合成src/SYNTHETIC_15.sv
