合成src/SYNTHETIC_17.sv
