合成src/SYNTHETIC_2.sv
