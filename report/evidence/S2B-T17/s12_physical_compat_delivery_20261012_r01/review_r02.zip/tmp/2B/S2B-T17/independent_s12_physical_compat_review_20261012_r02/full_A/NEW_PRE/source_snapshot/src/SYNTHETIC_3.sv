合成src/SYNTHETIC_3.sv
