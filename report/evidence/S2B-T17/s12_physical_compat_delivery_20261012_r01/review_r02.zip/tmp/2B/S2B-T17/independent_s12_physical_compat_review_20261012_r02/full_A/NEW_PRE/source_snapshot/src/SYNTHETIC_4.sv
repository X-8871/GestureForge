合成src/SYNTHETIC_4.sv
