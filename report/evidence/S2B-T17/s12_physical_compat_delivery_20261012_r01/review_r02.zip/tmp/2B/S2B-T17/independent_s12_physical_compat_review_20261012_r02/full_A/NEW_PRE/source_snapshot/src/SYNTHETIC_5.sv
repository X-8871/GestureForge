合成src/SYNTHETIC_5.sv
