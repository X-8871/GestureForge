合成src/SYNTHETIC_6.sv
