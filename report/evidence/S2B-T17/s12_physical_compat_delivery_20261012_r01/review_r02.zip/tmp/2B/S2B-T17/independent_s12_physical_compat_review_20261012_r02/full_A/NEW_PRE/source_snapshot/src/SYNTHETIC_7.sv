合成src/SYNTHETIC_7.sv
