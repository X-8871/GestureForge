合成src/SYNTHETIC_8.sv
