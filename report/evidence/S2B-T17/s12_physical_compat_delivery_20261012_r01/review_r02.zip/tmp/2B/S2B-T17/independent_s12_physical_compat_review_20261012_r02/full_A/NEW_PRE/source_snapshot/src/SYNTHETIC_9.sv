合成src/SYNTHETIC_9.sv
